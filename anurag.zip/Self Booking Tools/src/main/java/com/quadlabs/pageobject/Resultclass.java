package com.quadlabs.pageobject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.quadlabs.generic.Baselibrary;


public class Resultclass extends Baselibrary {

	
	public  static void book () throws Exception
	{
		
		 
		WebDriverWait	wait = new WebDriverWait(driver,50);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='progress-bar progress-bar-striped active']")));
		
		
		//getWebElement("BookNow").click();
	}
	public static  void validatefarecatefgory(String Faretype) throws Exception
	{
		
		SoftAssert asserts = new SoftAssert();
		
		List<WebElement> farecategory=driver.findElements(By.xpath("(//div[contains(@id,'tdContainerTblAirlines')]/ul)[1]/li"));
		for(WebElement faretype:farecategory)
		{
			
			if (faretype.getText().equalsIgnoreCase(Faretype))
			{
				faretype.click();
				
			}
				List<WebElement> faretypedata= driver.findElements(By.xpath("//span[@class='sq_supplier_lbl ng-binding']"));
			for(WebElement faredata:faretypedata)
			{      
				
				System.out.println(faredata.getSize());
				System.out.println(faredata.getText());
				String Actualresult=faredata.getText();
				System.out.println(Actualresult);
				String Expectedresult=Faretype;
				
				
				
				asserts.assertEquals(Actualresult, Expectedresult, "faretupe not verified");
				Reporter.log("Faretype verified",true);
				
			}	
			faretype.click();
		}
		
	}
	public static void policy() throws Exception
	{
		getWebElement("InPolicy").click();
		
		List<WebElement> inpolicylist=driver.findElements(By.xpath("//span[contains(@title,'In Policy')]"));
		for(WebElement data:inpolicylist)
		{
			data.getText();
			System.out.println(data.getText());
			SoftAssert asserts = new SoftAssert();
			String Actualresult=data.getText();
			System.out.println(Actualresult);
			String Expectedresult="In Policy";
			
			
			
			asserts.assertEquals(Actualresult, Expectedresult, "Policy not verified");
			Reporter.log("Policy verified",true);
			
		}
	}
}
